import pandas as pd

#Fonction pour calculer le nombre moyen de packets par flow
def moyennePacketsParSecond(df):
    df['Packets_per_flow'] = (df['FlowBytesSent'] + df['FlowBytesReceived']) / df['PacketLengthMedian']
    print('median', df['Packets_per_flow'].median())

#Fonction pour faire ressortir les différents IOC que l'on veut considérer
def get_ioc(df):
 #IOC sur tous le fichier malicieux
    print("Informations sur les flots n'utilisant pas DNS-over-HTTPS (DoH) :\n")
    print("\nIP impliquées :\n", df['SourceIP'].value_counts().head(10))
    print("\nIP impliquées :\n", df['DestinationIP'].value_counts().head(10))
    duree_anormales=df[df['Duration'] > df['Duration'].mean() + 2 * df['Duration'].std()]
    trafic_anormal=df[(df['PacketLengthVariance'] > 1000) | (df['PacketTimeVariance'] > 1000)]

    #print("\nPorts impliquées :\n", doh_iocs['SourcePort'].value_counts(),doh_iocs['DestinationPort'].value_counts() )
    print("\nDurées  anormales (dans les extremes):\n", duree_anormales)
    print("\nModèles de trafic suspects selon la longueur des paquets et leurs variance de temps:\n", trafic_anormal)
    
    anomalous_data_volume_out = df[df['FlowBytesSent'] > df['FlowBytesSent'].mean() + 2 * df['FlowBytesSent'].std()]
    anomalous_data_volume_in = df[df['FlowBytesReceived'] > df['FlowBytesReceived'].mean() + 2 * df['FlowBytesReceived'].std()]
    print("\Volume de données entrantes anormal :\n", anomalous_data_volume_in)
    print("\Volume de données entrantes anormal :\n", anomalous_data_volume_in)

    #IOC pour les flow filtrés dont DoH est a True 
    df_doh=df[df['DoH'] == 1]
    print("\nIP impliquées :\n", df_doh['SourceIP'].value_counts().head(10))
    print("\nIP impliquées :\n", df_doh['DestinationIP'].value_counts().head(10))
    df_doh=df[df['DoH'] == 0]
    print("\nIP impliquées :\n", df_doh['SourceIP'].value_counts().head(10))
    print("\nIP impliquées :\n", df_doh['DestinationIP'].value_counts().head(10))

#Fonction pour afficher les infos du dataframe filtré par IP (ici exemple 9.9.9.11)
def ip_infos(df):
    ip_source_filter = df['DestinationIP'] == '9.9.9.11'
    filtered_df = df[ip_source_filter]
    print("\nIP impliquées :\n", filtered_df['SourceIP'].value_counts().head(10))
    print("\nIP impliquées :\n", filtered_df['SourcePort'].value_counts().head(10))
    moyennePacketsParSecond(df)
    
    
#Appels aux différentes fonctions (décommenter aux besoins la ligne)
df = pd.read_csv('combined__benign_dataframe.csv')
#ip_infos(df)
#get_ioc(df)




