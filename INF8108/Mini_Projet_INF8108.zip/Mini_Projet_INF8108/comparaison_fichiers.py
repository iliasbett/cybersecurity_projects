import pandas as pd
import matplotlib.pyplot as plt


def moyennePacketsParSecond(file_name):
    df = pd.read_csv(file_name)
    df['Packets_per_flow'] = (df['FlowBytesSent'] + df['FlowBytesReceived']) / df['PacketLengthMedian']
    df['Packets_per_second'] = df['Packets_per_flow'] / df['Duration']
    print(df['Packets_per_second'])
    print('median', df['Packets_per_second'].median())
   
#Fonction pour comparer 2 columns de 2 fichiers différents afin de ressortir les différences   
def compare_unique_column(file_name1, file_name2, column):
    df1 = pd.read_csv(file_name1)
    df2 = pd.read_csv(file_name2)
    unique_elements_file1 = set(df1[column].unique())
    unique_elements_file2 = set(df2[column].unique())
    elements_only_in_file2 = unique_elements_file2 - unique_elements_file1
    print(column, "uniques dans le fichier 2 et non présentes dans le fichier 1:")
   
    return elements_only_in_file2
    
    
if __name__ == "__main__":
    file_name1='combined__malicious_dataframe.csv'
    file_name2='combined__benign_dataframe.csv'
    print(file_name1)
    result1= moyennePacketsParSecond(file_name1)
    print(file_name2)
    result2=moyennePacketsParSecond(file_name2)
    

# Imprimer les différences
    print('Résultat comparaison IPs source', compare_unique_column(file_name2, file_name1, 'SourceIP'))
    print('Résultat comparaison IPs destination', compare_unique_column(file_name2, file_name1, 'DestinationIP'))
    print('Résultat comparaison ports source', compare_unique_column(file_name2, file_name1, 'SourcePort'))
    print('Résultat comparaison ports destination', compare_unique_column(file_name2, file_name1, 'DestinationPort'), min(compare_unique_column(file_name2, file_name1, 'DestinationPort')), max(compare_unique_column(file_name2, file_name1, 'DestinationPort')))


   

  

    