import pandas as pd
import numpy as np
import os
from sklearn.preprocessing import MinMaxScaler

path_to_directory = os.path.dirname(os.path.realpath(__file__))



# Load the data from CSV file into a pandas DataFrame
df = pd.read_csv('combined_dataframe.csv')

# Select the columns you want to normalize
columns_to_normalize = ['FlowBytesSent', 'FlowSentRate', 'FlowBytesReceived','FlowReceivedRate','PacketLengthVariance','PacketLengthStandardDeviation','PacketLengthMean',	'PacketLengthMedian',	'PacketLengthMode',	'PacketLengthSkewFromMedian',	'PacketLengthSkewFromMode',	'PacketLengthCoefficientofVariation',	'PacketTimeVariance'	,'PacketTimeStandardDeviation',	'PacketTimeMean',	'PacketTimeMedian',	'PacketTimeMode',	'PacketTimeSkewFromMedian',	'PacketTimeSkewFromMode',	'PacketTimeCoefficientofVariation',	'ResponseTimeTimeVariance',	'ResponseTimeTimeStandardDeviation',	'ResponseTimeTimeMean',	'ResponseTimeTimeMedian',	'ResponseTimeTimeMode'	,'ResponseTimeTimeSkewFromMedian',	'ResponseTimeTimeSkewFromMode',	'ResponseTimeTimeCoefficientofVariation']

# Use MinMaxScaler from scikit-learn to normalize the selected columns
scaler = MinMaxScaler()
df[columns_to_normalize] = scaler.fit_transform(df[columns_to_normalize])

# Now, the selected columns are normalized in the DataFrame
# You can save the normalized DataFrame back to a CSV file if needed
df.to_csv('normalized_data.csv', index=False)





