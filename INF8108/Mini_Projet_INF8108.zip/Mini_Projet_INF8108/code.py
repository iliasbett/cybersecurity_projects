import pandas as pd
import numpy as np
import os

path_to_directory = r'C:\Users\sawse\Downloads\data-analysis\CSVs'
all_files = os.listdir(path_to_directory)

all_dataframes = []  # To store each DataFrame

for file in all_files:
    if file.endswith('.csv'):
        full_path = os.path.join(path_to_directory, file)
        df = pd.read_csv(full_path)
        all_dataframes.append(df)

combined_dataframe = pd.concat(all_dataframes, ignore_index=True)

## Replacing missing values
# For numeric columns, replace missing values with the median
numeric_cols = combined_dataframe.select_dtypes(include=[np.number]).columns
combined_dataframe[numeric_cols] = combined_dataframe[numeric_cols].fillna(combined_dataframe[numeric_cols].median())

# Optionally, for non-numeric columns, replace missing values with a placeholder or mode
non_numeric_cols = combined_dataframe.select_dtypes(exclude=[np.number]).columns
combined_dataframe[non_numeric_cols] = combined_dataframe[non_numeric_cols].fillna('placeholder_or_mode')

combined_dataframe.to_csv(r'C:\Users\sawse\Downloads\data-analysis\combined_dataframe.csv', index=False)

print(combined_dataframe.columns)

# OU remplacer par la moyenne (pour les données numériques)
# combined_dataframe.fillna(combined_dataframe.mean(), inplace=True)

# Supprimer des colonnes non nécessaires
# combined_dataframe.drop(['colonne_inutile1', 'colonne_inutile2'], axis=1, inplace=True)

# Convertir les données en types appropriés
# combined_dataframe['une_colonne'] = combined_dataframe['une_colonne'].astype('type')



