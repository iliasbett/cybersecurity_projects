import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

path_to_directory = r'C:\Users\sawse\Downloads\data-analysis'

# Load your datasets (assuming you've already done this)
benign_df = pd.read_csv('combined__benign_dataframe.csv')
malicious_df = pd.read_csv('combined__malicious_dataframe.csv')

# Basic Information
print("Benign Dataframe Info:")
print(benign_df.info())
print("\nMalicious Dataframe Info:")
print(malicious_df.info())

# Summary Statistics
print("\nBenign Dataframe Description:")
print(benign_df.describe())
print("\nMalicious Dataframe Description:")
print(malicious_df.describe())

# Checking for Missing Values
print("\nMissing Values in Benign Dataframe:")
print(benign_df.isnull().sum())
print("\nMissing Values in Malicious Dataframe:")
print(malicious_df.isnull().sum())

# Handling Missing Values (if needed)
benign_df['ResponseTimeTimeMedian'].fillna(benign_df['ResponseTimeTimeMedian'].median(), inplace=True)
benign_df['ResponseTimeTimeSkewFromMedian'].fillna(benign_df['ResponseTimeTimeSkewFromMedian'].median(), inplace=True)

malicious_df['ResponseTimeTimeMedian'].fillna(malicious_df['ResponseTimeTimeMedian'].median(), inplace=True)
malicious_df['ResponseTimeTimeSkewFromMedian'].fillna(malicious_df['ResponseTimeTimeSkewFromMedian'].median(), inplace=True)

# Data Distribution for key variables
plt.figure(figsize=(10, 6))
sns.histplot(benign_df['FlowBytesSent'], kde=True, color='blue', label='Benign')
sns.histplot(malicious_df['FlowBytesSent'], kde=True, color='red', label='Malicious')
plt.legend()
plt.title('Distribution of FlowBytesSent')
plt.show()

# Correlation Analysis
# plt.figure(figsize=(10, 8))
# sns.heatmap(benign_df.corr(), annot=True, fmt='.2f', cmap='Blues')
# plt.title('Correlation Matrix for Benign Dataframe')
# plt.show()

# Comparative Analysis (example)
# This can be tailored based on what specific comparisons are relevant
# plt.figure(figsize=(10, 6))
# sns.barplot(x='category_column', y='numeric_column', hue='dataset', data=pd.concat([benign_df.assign(dataset='Benign'), malicious_df.assign(dataset='Malicious')]))
# plt.title('Comparative Analysis of [Column Name]')
# plt.show()























## Replacing missing values
# For numeric columns, replace missing values with the median
#numeric_cols = combined_dataframe.select_dtypes(include=[np.number]).columns
#combined_dataframe[numeric_cols] = combined_dataframe[numeric_cols].fillna(combined_dataframe[numeric_cols].median())

# Optionally, for non-numeric columns, replace missing values with a placeholder or mode
#non_numeric_cols = combined_dataframe.select_dtypes(exclude=[np.number]).columns
#combined_dataframe[non_numeric_cols] = combined_dataframe[non_numeric_cols].fillna('placeholder_or_mode')
# Remplacer par la moyenne (pour les données numériques)
# combined_dataframe.fillna(combined_dataframe.mean(), inplace=True)

# Supprimer des colonnes non nécessaires
# combined_dataframe.drop(['colonne_inutile1', 'colonne_inutile2'], axis=1, inplace=True)

# Convertir les données en types appropriés
# combined_dataframe['une_colonne'] = combined_dataframe['une_colonne'].astype('type')



