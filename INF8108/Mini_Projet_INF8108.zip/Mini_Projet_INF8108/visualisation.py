
import pandas as pd
import matplotlib.pyplot as plt

# Charger le fichier CSV
donnees = pd.read_csv("combined__malicious_dataframe.csv")


# Filtrer les données pour les valeurs True et False dans la colonne DoH (décommenter la ligne selon le résultat voulu)
#donnees_doh_true = donnees[donnees['DoH'] == True]
donnees_doh_false = donnees[donnees['DoH'] == False]

ip_malicieuse = donnees[donnees['DestinationIP'].str.contains('9.9.9')]
ip_autres =donnees[~donnees['DestinationIP'].str.contains('9.9.9')]

# Créer l'histogramme (changer selon les données et colonnes qu'on veut représenter)
#plt.hist(donnees_doh_true['Duration'], alpha=0.5, label='DoH True')
#plt.hist(donnees_doh_false['PacketLengthMedian'], alpha=0.5, label='DoH False')

plt.hist(ip_malicieuse['PacketLengthMedian'], alpha=0.5, label='Destination is under the domain 9.9.9')
plt.hist(ip_autres['PacketLengthMedian'], alpha=0.5, label='other destinations')

# Ajouter des étiquettes et un titre
plt.xlabel('PacketLength')
plt.ylabel('Fréquence')
plt.title('Histogramme de la taille des paquets selon si la destination est sous le domaine 9.9.9')

# Afficher la légende
plt.legend()

# Afficher l'histogramme
plt.show()

